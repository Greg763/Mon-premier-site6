function altert() {
  alert("Alerte anti hackeur");
}
